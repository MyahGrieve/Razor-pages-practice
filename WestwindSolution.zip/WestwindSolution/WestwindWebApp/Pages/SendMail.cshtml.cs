using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Cryptography.X509Certificates;

namespace WestwindWebApp.Pages
{
    public class SendMailModel : PageModel
    {
        [TempData]
        public string FeedbackMessage { get; set; }

        [BindProperty]
        public string UserName { get; set; }

        [BindProperty]
        public string Password { get; set; }

        [BindProperty]
        public string MailTo { get; set; }

        [BindProperty]
        public string Subject { get; set; }

        [BindProperty]
        public string Message { get; set; }

        public void OnGet()
        {
        }

        public void OnPost()
        {
            FeedbackMessage = $"UserName = {UserName}, Password = {Password}, Mailing to = {MailTo}, Subject = {Subject}, Message = {Message}.";
        }
    }
}
